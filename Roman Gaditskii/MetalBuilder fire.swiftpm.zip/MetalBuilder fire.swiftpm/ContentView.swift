import SwiftUI
import MetalBuilder
import MetalKit
import MetalPerformanceShaders

struct Particle: MetalStruct{
    var coord: simd_float4 = [0, 0, 0, 0]
    var size: Float = 0
    var heat: Float = 0
}

let particlesCount = 2000

let desc = TextureDescriptor()
    .type(.type2D)
    .pixelFormatFromDrawable()
    .usage([.renderTarget, .shaderRead, .shaderWrite])
    .sizeFromViewport(scaled: 1)

struct ContentView: View {
    
    @MetalTexture(desc) var renderTexture
    @MetalTexture(desc
        .pixelFormat(.rgba16Float)) var blurTexture
    
    @MetalBuffer<Particle>(count: particlesCount, metalName: "particles") var particlesBuffer
    @MetalBuffer<Particle>(count: particlesCount) var particlesBuffer1
    
    @State var isDrawing = false
    @MetalState var particleId = 0
    
    @MetalState var dragging = false
    @MetalState var coord: simd_float2 = [0, 0]
    
    @State var threshold: Float = 0.15
    @State var sigma: Float = 10
    @State var brightness: Float = 1.7
    @State var fric: Float = 0.1
    @State var flameType: Float = 0
    @State var size: Float = 1
    
    var body: some View {
        VStack(alignment: .leading) {
            MetalBuilderView(librarySource: metalFunctions, helpers: helpers,
                             isDrawing: $isDrawing) { context in
                CPUCompute{
                    if $dragging.wrappedValue{
                        let scalingFactor: Float = 2
                        let coord = (scalingFactor*2*coord/simd_float2(context.viewportSize)-1)*simd_float2(1, -1)
                        spawnParticle(coord: coord, heat: 1)
                    }
                }
                Compute("integration")
                    .buffer(particlesBuffer, space: "device",
                            fitThreads: true)
                Compute("collision")
                    .buffer(particlesBuffer, space: "constant", name: "particlesIn",
                            fitThreads: true)
                    .buffer(particlesBuffer1, space: "device", name: "particlesOut")
                    .bytes($fric, name: "fric")
                BlitBuffer()
                    .source(particlesBuffer1)
                    .destination(particlesBuffer)
                Render(vertex: "vertexShader", fragment: "fragmentShader", type: .point, count: particlesCount)
                    .vertexBuf(particlesBuffer)
                    .vertexBytes(context.$viewportSize)
                    .fragBytes($flameType, name: "type")
                    .toTexture(renderTexture)
                MPSUnary { device in
                    MPSImageGaussianBlur(device: device, sigma: sigma)
                }
                .source(renderTexture)
                .destination(blurTexture)
                Compute("threshold")
                    .texture(blurTexture, argument: .init(type: "float", access: "read", name: "blur"))
                    .bytes($threshold, name: "threshold")
                    .bytes($brightness, name: "brightness")
                    .drawableTexture(argument: .init(type: "float", access: "write", name: "out"))
                
            }.onResize{ size in
                if !isDrawing{
                    isDrawing = true
                }
            }
            .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local)
                .onChanged{ value in
                    coord = [Float(value.location.x),
                             Float(value.location.y)]
                    dragging = true
                }
                .onEnded{_ in
                    dragging = false
                })
            Picker("flameType", selection: $flameType){
                Text("Circle").tag(Float(0))
                Text("Trapezoid").tag(Float(1))
            }.pickerStyle(.segmented)
            HStack{
                VStack(alignment: .leading, spacing: 18){
                    Text("Size: "+String(format:"%.3f", threshold))
                    Text("Threshold: "+String(format:"%.3f", threshold))
                    Text("Blur: "+String(format:"%.2f", sigma))
                    Text("Brightness: "+String(format:"%.3f", brightness))
                    Text("Friction: "+String(format:"%.3f", fric))
                }
                .font(.system(.body).monospacedDigit())
                .frame(width: 150, alignment: .leading)
                .padding()
                Spacer()
                VStack{
                    Slider(value: $size, in: 0.1...2)
                    Slider(value: $threshold, in: 0...0.2)
                    Slider(value: $sigma, in: 0...50)
                    Slider(value: $brightness, in: 0...50)
                    Slider(value: $fric, in: 0...10)
                }
                .padding()
            }
        }
    }
    func spawnParticle(coord: simd_float2, heat: Float){
        let velo = simd_float2.init(repeating: 0)
        let coord = coord+simd_float2.random(in: -0.05...0.05)
        let size = Float.random(in: 0.5...0.7)*size
        particlesBuffer.pointer![particleId] = Particle(coord: [coord.x, coord.y, coord.x-velo.x, coord.y-velo.y],
                                                        size: size,
                                                        heat: heat)
        particleId = (particleId+1) % particlesCount
    }
}
