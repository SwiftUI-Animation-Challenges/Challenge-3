let helpers = """
float sdTrapezoid(float2 p, float r1, float r2, float he )
{
    float2 k1 = float2(r2,he);
    float2 k2 = float2(r2-r1,2.0*he);
    p.x = abs(p.x);
    float2 ca = float2(p.x-min(p.x,(p.y<0.0)?r1:r2), abs(p.y)-he);
    float2 cb = p - k1 + k2*clamp( dot(k1-p,k2)/dot(k2, k2), 0.0, 1.0 );
    float s = (cb.x<0.0 && ca.y<0.0) ? -1.0 : 1.0;
    return s*sqrt( min(dot(ca, ca),dot(cb, cb)) );
}
float sdCircle( float2 p, float r )
{
    return length(p) - r;
}
"""
let metalFunctions = """
struct VertexOut{
    float4 position [[position]];
    float size [[point_size]];
    float4 color; 
};
vertex VertexOut
vertexShader(uint id [[vertex_id]]){
  VertexOut out;
  Particle p = particles[id];
  out.position = float4(p.coord.xy, 0, 1);
  out.size = p.size*float(viewportSize.x)*0.3*p.heat;
  out.color = float4(pow(p.heat, 2), pow(p.heat, 3.), pow(p.heat, 8.), 1);
  return out;
}
fragment float4 fragmentShader(VertexOut in [[stage_in]],
                               float2 p [[point_coord]]){
    float d1 = sdCircle(p-.5, .5);
    float d2 = sdTrapezoid(p-.5, .01, .3, .5);
    
    float mask = smoothstep(.01, 0., type==0. ? d1 : d2);
    if (mask==0) discard_fragment();
    return in.color;
}
kernel void integration(uint id [[thread_position_in_grid]]){
   //Integration
   Particle p = particles[id];
   float2 velo = p.coord.xy-p.coord.zw;
   p.coord.zw = p.coord.xy;
   velo += float2(0, -0.001+p.heat*0.002);
   //velo *= -1*(ceil(max(0., abs(p.coord.xy)-1.))*2-1);
   p.coord.xy += velo;//*0.99;

   p.heat-=p.heat*.02;
   if(p.heat<.01)p.size=0.;

   //Edge constraint
   if (p.coord.x>1) p.coord.x=1;
   if (p.coord.x<-1) p.coord.x=-1;
   if (p.coord.y>1) p.coord.y=1;
   if (p.coord.y<-1) p.coord.y=-1;

   //if (p.coord.y<-.9) p.heat+=0.03;

   particles[id] = p;
}

kernel void collision(uint id [[thread_position_in_grid]],
                      uint count [[threads_per_grid]]){
  Particle p = particlesIn[id];
  for(uint id1=0; id1<count; id1++){
      if (id==id1) continue;
      Particle p1 = particlesIn[id1];
      float2 axis = p1.coord.xy - p.coord.xy;
      float dist = length(axis);
       if (dist == 0) continue;
      float size = p.size+p1.size;
      if (dist<size){
        float shift = size-dist;
        float2 n = axis/dist;
        p.coord.xy -= (p.size/size)*shift*n*fric*.000005;
      }
   }
   particlesOut[id] = p;
}
kernel void threshold(uint2 gid [[thread_position_in_grid]]){
     float3 in = blur.read(gid).rgb;
     float3 hue = normalize(in);
     float light = smoothstep(threshold, threshold+0.01, length(in));
     float3 color = pow(hue*light*brightness, 2.2);
     out.write(float4(color, 1), gid);
}
"""
